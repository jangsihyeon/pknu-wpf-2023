﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace wp05_bikeshop.Logics
{
    internal class Human
    {
        public string FullName { get; set; }
        public bool HasLicense { get; set; }
    }
}
