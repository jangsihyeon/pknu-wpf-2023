﻿using System.Windows.Media;

namespace wp05_bikeshop.Logics
{
    public class Car
    {
        public string Name{get; set;}  // auto property  
        public double Speed {get; set;}
        public Color Colors {get; set;}
        //public Human Driver { get; set;}
    }
}